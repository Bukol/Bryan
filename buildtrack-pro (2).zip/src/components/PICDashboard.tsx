import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  ClipboardList, Plus, Loader2, Home, 
  Users, Calendar, AlertCircle, Cloud, Camera, Send
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { io } from 'socket.io-client';

interface House {
  id: number;
  house_number: string;
  subcontractor_name: string;
  progress_percentage: number;
  status: string;
  start_date: string;
}

interface LogEntry {
  id: number;
  house_number: string;
  subcontractor_name: string;
  date: string;
  task_description: string;
  manpower: number;
  weather: string;
  progress_added: number;
  issues: string;
  user_name: string;
}

export default function PICDashboard() {
  const { token, logout, user } = useAuth();
  const [houses, setHouses] = useState<House[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [selectedHouse, setSelectedHouse] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<'home' | 'logs' | 'schedule'>('home');

  // Form State
  const [formData, setFormData] = useState({
    task_description: '',
    manpower: 1,
    issues: '',
    weather: 'Sunny',
    progress_added: 5,
    photo_url: ''
  });

  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [assignHouseId, setAssignHouseId] = useState<number | null>(null);
  const [assignData, setAssignData] = useState({ house_number: '', start_date: new Date().toISOString().split('T')[0] });
  const [assignLoading, setAssignLoading] = useState(false);

  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isConnected, setIsConnected] = useState(false);

  const fetchData = async () => {
    try {
      const [housesRes, logsRes] = await Promise.all([
        fetch('/api/houses', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/logs', { headers: { Authorization: `Bearer ${token}` } })
      ]);
      const housesData = await housesRes.json();
      const logsData = await logsRes.json();
      setHouses(housesData);
      setLogs(logsData);
      setLastUpdated(new Date());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const socket = io();
    socket.on('connect', () => setIsConnected(true));
    socket.on('disconnect', () => setIsConnected(false));
    socket.on('data_updated', fetchData);
    return () => { socket.disconnect(); };
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHouse) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/logs', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ ...formData, house_id: selectedHouse })
      });
      if (res.ok) {
        setIsLogModalOpen(false);
        setFormData({
          task_description: '',
          manpower: 1,
          issues: '',
          weather: 'Sunny',
          progress_added: 5,
          photo_url: ''
        });
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignHouseId) return;
    setAssignLoading(true);
    try {
      const res = await fetch('/api/houses/assign', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ ...assignData, house_id: assignHouseId })
      });
      if (res.ok) {
        setIsAssignModalOpen(false);
        setAssignData({ house_number: '', start_date: new Date().toISOString().split('T')[0] });
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAssignLoading(false);
    }
  };

  if (loading) return (
    <div className="flex items-center justify-center h-screen">
      <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
    </div>
  );

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6 pb-24 md:pb-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            {activeTab === 'home' ? 'Site Engineer Log' : activeTab === 'logs' ? 'Activity History' : 'Project Schedule'}
          </h1>
          <div className="flex items-center gap-2 text-slate-500 text-sm">
            <span>Welcome, {user?.name}</span>
            <span className="text-slate-300">•</span>
            <div className="flex items-center gap-1.5">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
              <span className="text-xs font-medium">{isConnected ? 'Live' : 'Offline'}</span>
            </div>
            <span className="text-slate-300">•</span>
            <span className="text-xs">{lastUpdated.toLocaleTimeString()}</span>
          </div>
        </div>
        <button onClick={logout} className="text-sm text-slate-500 hover:text-red-600 transition-colors">Logout</button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'home' && (
          <motion.div 
            key="home"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6"
          >
            <div className="bg-emerald-600 p-6 rounded-2xl text-white shadow-lg shadow-emerald-100">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <ClipboardList className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold">Daily Site Entry</h2>
                  <p className="text-emerald-100 text-sm">Update progress for today's tasks</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Active Houses</h3>
              {houses.filter(h => h.status !== 'Finished' && h.house_number !== 'Pending Assignment').map((house) => (
                <motion.div 
                  key={house.id}
                  layoutId={`house-${house.id}`}
                  className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center text-slate-400">
                      <Home className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">{house.house_number}</h4>
                      <p className="text-xs text-slate-500">{house.subcontractor_name}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="hidden sm:block text-right">
                      <p className="text-xs text-slate-400 mb-1">Current Progress</p>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500" style={{ width: `${house.progress_percentage}%` }} />
                        </div>
                        <span className="text-xs font-bold text-slate-700">{house.progress_percentage}%</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => { setSelectedHouse(house.id); setIsLogModalOpen(true); }}
                      className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center hover:bg-emerald-100 transition-colors"
                    >
                      <Plus className="w-6 h-6" />
                    </button>
                  </div>
                </motion.div>
              ))}
              {houses.filter(h => h.status !== 'Finished' && h.house_number !== 'Pending Assignment').length === 0 && (
                <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-200">
                  <p className="text-slate-400 text-sm">No active assigned houses. Check Schedule for pending assignments.</p>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'logs' && (
          <motion.div 
            key="logs"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-4"
          >
            {logs.map((log) => (
              <div key={log.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-900">{log.house_number}</h4>
                    <p className="text-xs text-slate-500">{log.subcontractor_name}</p>
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase bg-slate-50 px-2 py-1 rounded">
                    {new Date(log.date).toLocaleDateString()}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center py-2 border-y border-slate-50">
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold">Manpower</p>
                    <p className="text-sm font-bold text-slate-700">{log.manpower}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold">Weather</p>
                    <p className="text-sm font-bold text-slate-700">{log.weather}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold">Progress</p>
                    <p className="text-sm font-bold text-emerald-600">+{log.progress_added}%</p>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Task</p>
                  <p className="text-sm text-slate-600">{log.task_description}</p>
                </div>
                {log.issues && (
                  <div className="bg-amber-50 p-2 rounded-lg flex gap-2 items-start">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-700">{log.issues}</p>
                  </div>
                )}
              </div>
            ))}
            {logs.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-200">
                <p className="text-slate-400 text-sm">No logs submitted yet.</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'schedule' && (
          <motion.div 
            key="schedule"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-4"
          >
            {houses.map((house) => (
              <div key={house.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${house.house_number === 'Pending Assignment' ? 'bg-amber-50 text-amber-600' : house.status === 'Finished' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className={`font-bold ${house.house_number === 'Pending Assignment' ? 'text-amber-600 italic' : 'text-slate-900'}`}>{house.house_number}</h4>
                    <p className="text-xs text-slate-500">Subcon: {house.subcontractor_name}</p>
                    <p className="text-xs text-slate-500">Start: {house.start_date ? new Date(house.start_date).toLocaleDateString() : 'Not Set'}</p>
                  </div>
                </div>
                <div className="text-right flex flex-col items-end gap-2">
                  <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded ${
                    house.status === 'Finished' ? 'bg-emerald-100 text-emerald-700' : 
                    house.status === 'Ongoing' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {house.status}
                  </span>
                  {house.status === 'Not Started' && (
                    <button 
                      onClick={() => { 
                        setAssignHouseId(house.id); 
                        setAssignData({ 
                          house_number: house.house_number === 'Pending Assignment' ? '' : house.house_number, 
                          start_date: house.start_date || new Date().toISOString().split('T')[0] 
                        });
                        setIsAssignModalOpen(true); 
                      }}
                      className={`text-xs font-bold px-3 py-1 rounded-lg transition-colors ${
                        house.house_number === 'Pending Assignment' 
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
                        : 'text-emerald-600 hover:text-emerald-700 underline'
                      }`}
                    >
                      {house.house_number === 'Pending Assignment' ? 'Assign Now' : 'Edit Details'}
                    </button>
                  )}
                  <p className="text-xs font-bold text-slate-400">{house.progress_percentage}% Done</p>
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Assignment Modal */}
      <AnimatePresence>
        {isAssignModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 relative"
            >
              <h3 className="text-xl font-bold mb-6">Assign House Details</h3>
              <form onSubmit={handleAssign} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">House Number / Block</label>
                  <input 
                    type="text" 
                    required
                    placeholder="e.g. Block 5 Lot 12"
                    value={assignData.house_number}
                    onChange={(e) => setAssignData({...assignData, house_number: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Commencement Date</label>
                  <input 
                    type="date" 
                    required
                    value={assignData.start_date}
                    onChange={(e) => setAssignData({...assignData, start_date: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div className="flex gap-3 pt-4">
                  <button 
                    type="button"
                    onClick={() => setIsAssignModalOpen(false)}
                    className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={assignLoading}
                    className="flex-1 px-4 py-2 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {assignLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Assignment'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Log Entry Modal */}
      <AnimatePresence>
        {isLogModalOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50 backdrop-blur-sm">
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl w-full max-w-lg p-6 sm:p-8 relative max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Daily Site Log</h3>
                <button onClick={() => setIsLogModalOpen(false)} className="text-slate-400 hover:text-slate-600">✕</button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Manpower</label>
                    <div className="relative">
                      <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                      <input 
                        type="number" 
                        required
                        value={isNaN(formData.manpower) ? '' : formData.manpower}
                        onChange={e => setFormData({...formData, manpower: parseInt(e.target.value)})}
                        className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Weather</label>
                    <div className="relative">
                      <Cloud className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                      <select 
                        value={formData.weather}
                        onChange={e => setFormData({...formData, weather: e.target.value})}
                        className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 appearance-none"
                      >
                        <option>Sunny</option>
                        <option>Rainy</option>
                        <option>Cloudy</option>
                        <option>Stormy</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Task Performed</label>
                  <textarea 
                    required
                    placeholder="Describe work done today..."
                    value={formData.task_description}
                    onChange={e => setFormData({...formData, task_description: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 h-24 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Progress Added (%)</label>
                  <input 
                    type="range" 
                    min="1" 
                    max="100" 
                    value={formData.progress_added}
                    onChange={e => setFormData({...formData, progress_added: parseInt(e.target.value)})}
                    className="w-full accent-emerald-600 h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between mt-1">
                    <span className="text-xs text-slate-400">0%</span>
                    <span className="text-sm font-bold text-emerald-600">{formData.progress_added}%</span>
                    <span className="text-xs text-slate-400">100%</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Issues Encountered (Optional)</label>
                  <div className="relative">
                    <AlertCircle className="absolute left-3 top-3 text-slate-400 w-4 h-4" />
                    <textarea 
                      placeholder="Any delays or problems?"
                      value={formData.issues}
                      onChange={e => setFormData({...formData, issues: e.target.value})}
                      className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 h-20 resize-none"
                    />
                  </div>
                </div>

                <div className="flex gap-4 pt-2">
                  <button 
                    type="button"
                    className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-colors flex items-center justify-center gap-2"
                  >
                    <Camera className="w-5 h-5" />
                    Photo
                  </button>
                  <button 
                    type="submit"
                    disabled={submitting}
                    className="flex-[2] py-3 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Send className="w-5 h-5" /> Submit Log</>}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 px-6 py-3 flex justify-around items-center md:hidden z-40">
        <button 
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'home' ? 'text-emerald-600' : 'text-slate-400'}`}
        >
          <Home className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Home</span>
        </button>
        <button 
          onClick={() => setActiveTab('logs')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'logs' ? 'text-emerald-600' : 'text-slate-400'}`}
        >
          <ClipboardList className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Logs</span>
        </button>
        <button 
          onClick={() => setActiveTab('schedule')}
          className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'schedule' ? 'text-emerald-600' : 'text-slate-400'}`}
        >
          <Calendar className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Schedule</span>
        </button>
      </div>
    </div>
  );
}
